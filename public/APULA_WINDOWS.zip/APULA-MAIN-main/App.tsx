
import React, { useState, useEffect, useRef, useCallback } from 'react';
import Header from './components/Header';
import SensorStatusPanel from './components/SensorStatus';
import Statistics from './components/Statistics';
import ArduinoConnect from './components/ArduinoConnect';
import AlarmSystem from './components/AlarmSystem';
import LoadingScreen from './components/LoadingScreen';
import LiveCamera from './components/LiveCamera';
import DownloadPage from './components/DownloadPage';
import GuidesPage from './components/GuidesPage';
import SerialConnect from './components/SerialConnect';
import { SensorData, SensorStatus, HistoryPoint, ConnectionState } from './types';
import { notificationService } from './utils/notifications';

const INITIAL_SENSORS: SensorData[] = [
  { id: '1', name: 'Alpha Zone', value: 0, status: SensorStatus.NOT_READY, lastUpdated: 'Disconnected' },
  { id: '2', name: 'Beta Zone', value: 0, status: SensorStatus.NOT_READY, lastUpdated: 'Disconnected' },
  { id: '3', name: 'Gamma Zone', value: 0, status: SensorStatus.NOT_READY, lastUpdated: 'Disconnected' },
];

const App: React.FC = () => {
  const [isLoading, setIsLoading] = useState(true);
  const [showDashboard, setShowDashboard] = useState(false);
  const [isMobileAppMode, setIsMobileAppMode] = useState(false);
  const [isGuidesMode, setIsGuidesMode] = useState(false);
  const [sensors, setSensors] = useState<SensorData[]>(INITIAL_SENSORS);
  const [history, setHistory] = useState<HistoryPoint[]>([]);
  const [fireIncidentCount, setFireIncidentCount] = useState(0);
  const [connection, setConnection] = useState<ConnectionState>(ConnectionState.DISCONNECTED);
  const [activeIp, setActiveIp] = useState("10.209.255.30");
  const [isAlarmActive, setIsAlarmActive] = useState(false);
  const [isTestActive, setIsTestActive] = useState(false);
  const [connectionMode, setConnectionMode] = useState<'wireless' | 'wired'>('wireless');
  
  const sensorSocketRef = useRef<WebSocket | null>(null);
  const serialPortRef = useRef<any>(null);
  const serialBufferRef = useRef<string>("");
  const fireInCurrentTurn = useRef(false);

  const handleLoadingFinished = () => {
    setIsLoading(false);
    setShowDashboard(true);
  };

  useEffect(() => {
    // Request notification permission on startup
    notificationService.requestPermission();
  }, []);

  useEffect(() => {
    const fireDetected = sensors.some(s => s.status === SensorStatus.FIRE_DETECTED);
    if (fireDetected && !isAlarmActive && !fireInCurrentTurn.current) {
      setIsAlarmActive(true);
      setFireIncidentCount(prev => prev + 1);
      fireInCurrentTurn.current = true;

      // Send Browser Notification
      notificationService.notify('🔥 FIRE ALERT: APULA SYSTEM', {
        body: 'Fire detected in one of the zones! Immediate action required.',
        tag: 'fire-alert',
        requireInteraction: true
      });
    } else if (!fireDetected) {
      fireInCurrentTurn.current = false;
    }
  }, [sensors, isAlarmActive]);

  const processSensorData = useCallback((data: string) => {
    const raw = data.trim().toUpperCase();
    if (isTestActive) return;

    // Default values
    let sensorValues = [0, 0, 0];

    if (raw.includes("SENSORS:")) {
      const payload = raw.split("SENSORS:")[1];
      const values = payload.split(',').map(v => parseInt(v.trim(), 10));
      if (values.length >= 3) {
        // Dashboard expects intensity 0-100. Analog is 0-1023.
        // For flame sensors, LOW (0) is fire. In analog, lower values usually mean fire.
        // We'll normalize: (1023 - val) / 10.23 to get 0-100% intensity
        sensorValues = values.map(v => Math.max(0, Math.min(100, Math.round((1023 - v) / 10.23))));
      }

      setSensors(prev => prev.map((s, i) => {
        const intensity = sensorValues[i];
        const isFlame = intensity > 50; // Trigger threshold
        const newStatus = isFlame ? SensorStatus.FIRE_DETECTED : SensorStatus.SAFE;
        
        return {
          ...s,
          value: intensity,
          status: newStatus,
          lastUpdated: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })
        };
      }));
    }
  }, [isTestActive]);

  const connectWirelessSensors = (ipOrSsid: string, pass: string) => {
    if (sensorSocketRef.current) sensorSocketRef.current.close();
    
    setConnection(ConnectionState.CONNECTING);
    try {
      // Check if input is a valid IP address. If not, default to the user's fixed IP.
    const isIp = /^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$/.test(ipOrSsid);
    let targetIp = isIp ? ipOrSsid : "10.209.255.30"; 
    
    console.log(`Attempting connection to ${targetIp}...`);
      setActiveIp(targetIp);
      
      const socket = new WebSocket(`ws://${targetIp}:82`);
      
      let connectionTimeout = setTimeout(() => {
        if (socket.readyState !== WebSocket.OPEN) {
          console.log("Primary IP timed out. Trying AP Mode IP (192.168.4.1)...");
          socket.close();
          tryAPFallback();
        }
      }, 3000);

      const tryAPFallback = () => {
        const apIp = "192.168.4.1";
        setActiveIp(apIp);
        const apSocket = new WebSocket(`ws://${apIp}:82`);
        
        apSocket.onopen = () => {
          setConnection(ConnectionState.CONNECTED);
          setConnectionMode('wireless');
          setSensors(prev => prev.map(s => ({ ...s, status: SensorStatus.READY })));
          console.log(`Connected to AP Mode: ${apIp}`);
        };

        apSocket.onmessage = (event) => processSensorData(event.data);
        apSocket.onclose = () => {
          setConnection(ConnectionState.DISCONNECTED);
          setSensors(INITIAL_SENSORS);
        };
        apSocket.onerror = () => setConnection(ConnectionState.ERROR);
        sensorSocketRef.current = apSocket;
      };

      socket.onopen = () => {
        clearTimeout(connectionTimeout);
        setConnection(ConnectionState.CONNECTED);
        setConnectionMode('wireless');
        setSensors(prev => prev.map(s => ({ ...s, status: SensorStatus.READY })));
        console.log(`Connected to Station Mode: ${targetIp}`);
      };

      socket.onmessage = (event) => {
        processSensorData(event.data);
      };

      socket.onclose = () => {
        setConnection(ConnectionState.DISCONNECTED);
        setSensors(INITIAL_SENSORS);
      };

      socket.onerror = (error) => {
        setConnection(ConnectionState.ERROR);
        console.error("WebSocket Error:", error);
      };

      sensorSocketRef.current = socket;
    } catch (err) {
      setConnection(ConnectionState.ERROR);
    }
  };

  const disconnectWirelessSensors = () => {
    if (sensorSocketRef.current) sensorSocketRef.current.close();
    setConnection(ConnectionState.DISCONNECTED);
    setSensors(INITIAL_SENSORS);
  };

  const handleSerialData = (data: string) => {
    serialBufferRef.current += data;
    if (serialBufferRef.current.includes('\n')) {
      const lines = serialBufferRef.current.split('\n');
      serialBufferRef.current = lines.pop() || "";
      lines.forEach(line => {
        if (line.trim()) processSensorData(line);
      });
    }
  };

  const onSerialConnect = (port: any) => {
    serialPortRef.current = port;
    setConnection(ConnectionState.CONNECTED);
    setConnectionMode('wired');
    setSensors(prev => prev.map(s => ({ ...s, status: SensorStatus.READY })));
  };

  const onSerialDisconnect = () => {
    serialPortRef.current = null;
    setConnection(ConnectionState.DISCONNECTED);
    setSensors(INITIAL_SENSORS);
  };
  
  const triggerTestAlarm = () => {
    setIsTestActive(true);
    setSensors(prev => prev.map((s, i) => i === 0 ? { 
      ...s, 
      value: 100, 
      status: SensorStatus.FIRE_DETECTED,
      lastUpdated: 'TEST_MODE'
    } : s));

    // If connected via Serial, send TEST_PANIC command to Arduino
    if (connection === ConnectionState.CONNECTED && connectionMode === 'wired' && serialPortRef.current) {
      const writer = serialPortRef.current.writable.getWriter();
      const encoder = new TextEncoder();
      writer.write(encoder.encode("TEST_PANIC\n"));
      writer.releaseLock();
    }
    // If connected via Wireless, send TEST_PANIC command to ESP32
    else if (connection === ConnectionState.CONNECTED && connectionMode === 'wireless' && sensorSocketRef.current) {
      sensorSocketRef.current.send("TEST_PANIC");
    }
  };

  const acknowledgeAlarm = () => {
    setIsAlarmActive(false);
    if (isTestActive) {
      setIsTestActive(false);
      setSensors(prev => prev.map(s => ({ 
        ...s, 
        status: connection === ConnectionState.CONNECTED ? SensorStatus.READY : SensorStatus.NOT_READY 
      })));
    }
  };

  useEffect(() => {
    const point: HistoryPoint = {
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      alpha: sensors[0].value,
      beta: sensors[1].value,
      gamma: sensors[2].value
    };
    setHistory(prev => [...prev.slice(-19), point]);
  }, [sensors]);

  if (isLoading) return <LoadingScreen onFinished={handleLoadingFinished} />;

  if (isMobileAppMode) {
    return <DownloadPage onBack={() => setIsMobileAppMode(false)} />;
  }

  if (isGuidesMode) {
    return <GuidesPage onBack={() => setIsGuidesMode(false)} />;
  }

  return (
    <div className={`transition-all duration-700 ease-out ${showDashboard ? 'opacity-100 scale-100' : 'opacity-100 scale-100'}`}>
      <AlarmSystem isActive={isAlarmActive} onAcknowledge={acknowledgeAlarm} />
      <div className="max-w-[1700px] mx-auto px-4 pb-12 overflow-x-hidden">
        <header className="bg-orange-600 shadow-2xl p-4 md:p-6 rounded-b-[30px] md:rounded-b-[40px] flex flex-col md:flex-row items-center justify-between border-b-4 md:border-b-8 border-orange-800">
          <div className="flex items-center gap-3 md:gap-4 mb-4 md:mb-0">
            <div className="bg-white p-2 md:p-3 rounded-xl md:rounded-2xl shadow-inner">
              <i className="fa-solid fa-fire-extinguisher text-2xl md:text-4xl text-orange-600"></i>
            </div>
            <div>
              <h1 className="text-3xl md:text-4xl font-black tracking-tighter text-white leading-none">APULA</h1>
              <p className="text-[8px] md:text-[10px] font-bold text-orange-200 uppercase tracking-widest mt-1 opacity-80">Prevention Unit // ESP32 Sync</p>
            </div>
          </div>
          
          <div className="flex flex-col items-center md:items-end gap-3">
            <button 
              onClick={() => setIsMobileAppMode(true)}
              className="bg-white/10 hover:bg-white/20 text-white px-4 py-2 rounded-xl border border-white/20 transition-all font-black uppercase tracking-widest text-[9px] flex items-center gap-2 group"
            >
              <i className="fa-solid fa-download group-hover:translate-y-0.5 transition-transform"></i>
              Downloads
            </button>
            <div className="flex flex-col items-center md:items-end">
              <div className="text-2xl md:text-3xl font-black text-white tabular-nums drop-shadow-md leading-none">
                {new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: true })}
              </div>
            </div>
          </div>
        </header>
        
        {/* Navigation Controls */}
        <div className="mt-6 flex justify-end gap-3 md:gap-4">
          <button 
            onClick={() => setIsGuidesMode(true)}
            className="bg-stone-900 hover:bg-emerald-600 text-emerald-500 hover:text-white px-5 md:px-8 py-3 md:py-4 rounded-2xl border-2 border-emerald-600/30 hover:border-emerald-500 transition-all font-black uppercase tracking-widest text-[9px] md:text-xs flex items-center gap-3 shadow-lg group"
          >
            <i className="fa-solid fa-book-open group-hover:scale-110 transition-transform"></i>
            System Guides
          </button>
        </div>
        
        <main className="mt-8 md:mt-12 grid grid-cols-1 lg:grid-cols-12 gap-6 md:gap-10 items-start">
          <div className="lg:col-span-7 xl:col-span-8 flex flex-col gap-6 md:gap-10">
            <LiveCamera ipAddress={activeIp} />
            <Statistics data={history} fireCount={fireIncidentCount} />
            
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 md:gap-10">
              <ArduinoConnect 
                state={connectionMode === 'wireless' ? connection : ConnectionState.DISCONNECTED} 
                onConnect={connectWirelessSensors} 
                onDisconnect={disconnectWirelessSensors}
                label="Wireless Hub"
                defaultSsid="APULA_FIRE_SYSTEM"
                defaultPass="FireSafe2026"
              />
              <SerialConnect
                state={connectionMode === 'wired' ? connection : ConnectionState.DISCONNECTED}
                onData={handleSerialData}
                onConnect={onSerialConnect}
                onDisconnect={onSerialDisconnect}
              />
            </div>
          </div>

          <div className="lg:col-span-5 xl:col-span-4 flex flex-col gap-6 md:gap-8 lg:sticky lg:top-8">
            <div className={`rounded-[35px] md:rounded-[45px] p-8 md:p-12 border-b-[10px] md:border-b-[15px] transition-all flex items-center justify-between shadow-2xl relative overflow-hidden ${
              sensors.some(s => s.status === SensorStatus.FIRE_DETECTED) 
              ? 'bg-red-700 border-red-900 animate-pulse' 
              : connection === ConnectionState.CONNECTED ? 'bg-emerald-600 border-emerald-800' : 'bg-stone-800 border-stone-900'
            }`}>
               <div className="text-white relative z-10">
                  <h3 className="text-[11px] md:text-xs font-black uppercase tracking-[0.3em] mb-2 opacity-70">Detection Grid</h3>
                  <p className="text-2xl md:text-5xl font-black uppercase tracking-tighter leading-none">
                    {sensors.some(s => s.status === SensorStatus.FIRE_DETECTED) ? 'PANIC ACTIVE' : 
                     connection === ConnectionState.CONNECTED ? (connectionMode === 'wireless' ? 'ARMED (WIFI)' : 'ARMED (USB)') : 'STANDBY'}
                  </p>
               </div>
               <i className={`fa-solid ${sensors.some(s => s.status === SensorStatus.FIRE_DETECTED) ? 'fa-fire-alt' : 'fa-shield-halved'} text-4xl md:text-7xl text-white opacity-80 z-10`}></i>
               <div className="absolute -right-4 -top-4 w-32 h-32 bg-white/10 blur-3xl rounded-full"></div>
            </div>

            <SensorStatusPanel sensors={sensors} />
            
            <div className="bg-stone-900 rounded-[35px] md:rounded-[45px] p-8 md:p-12 border-b-[10px] md:border-b-[15px] border-stone-950 flex flex-col gap-6 md:gap-8 shadow-2xl">
              <h4 className="text-[11px] md:text-xs font-black text-stone-500 uppercase tracking-widest border-l-4 border-orange-600 pl-4">Directive Control Console</h4>
              
              <button 
                className="w-full bg-red-600 hover:bg-red-500 active:scale-95 text-white font-black py-5 md:py-8 rounded-2xl md:rounded-[35px] border-b-8 md:border-b-[12px] border-red-800 transition-all uppercase flex items-center justify-center gap-4 text-sm md:text-2xl shadow-xl"
                onClick={triggerTestAlarm}
              >
                <i className="fa-solid fa-radiation animate-spin-slow text-2xl md:text-4xl"></i>
                Simulate Panic
              </button>

              <div className="grid grid-cols-2 gap-4 md:gap-6">
                <button 
                  onClick={() => setFireIncidentCount(0)}
                  className="bg-stone-800 hover:bg-stone-700 text-stone-400 font-black py-4 md:py-6 rounded-xl md:rounded-[25px] border-b-4 border-stone-950 transition-all uppercase text-[10px] md:text-xs tracking-widest"
                >
                  Clear Logs
                </button>
                <button 
                  onClick={() => setSensors(INITIAL_SENSORS)}
                  className="bg-stone-800 hover:bg-stone-700 text-stone-400 font-black py-4 md:py-6 rounded-xl md:rounded-[25px] border-b-4 border-stone-950 transition-all uppercase text-[10px] md:text-xs tracking-widest"
                >
                  Hard Reset
                </button>
              </div>
            </div>
          </div>
        </main>

        <footer className="mt-20 md:mt-32 pt-12 md:pt-16 border-t border-white/5 text-center text-stone-600">
          <p className="text-[10px] md:text-[13px] font-black uppercase tracking-[0.5em] mb-4 text-stone-500/50">APULA SYSTEM ARCHITECTURE // HARDWARE SYNC V2.7.0</p>
        </footer>
      </div>
      
      <style>{`
        .animate-spin-slow { animation: spin 4s linear infinite; }
        @keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }
      `}</style>
    </div>
  );
};

export default App;
