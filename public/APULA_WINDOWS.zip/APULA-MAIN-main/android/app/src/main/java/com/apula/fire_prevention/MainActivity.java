package com.apula.fire_prevention;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
