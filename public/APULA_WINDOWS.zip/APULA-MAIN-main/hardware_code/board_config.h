
#pragma once

// ===========================
// Select camera model
// ===========================
#ifndef CAMERA_MODEL_AI_THINKER
#define CAMERA_MODEL_AI_THINKER // Default model for ESP32-CAM
#endif

#include "camera_pins.h"
